const { addonBuilder, serveHTTP } = require("stremio-addon-sdk");

const config = require("../config/app");
const manifest = require("./manifest");

const catalogHandler = require("./handlers/catalog");
const metaHandler = require("./handlers/meta");
const streamHandler = require("./handlers/stream");

const { loadChannels } = require("./services/channelRepository");

const { loadEpg } = require("./services/epgLoader");
const { loadProgrammes } = require("./services/epgRepository");

const builder = new addonBuilder(manifest);

builder.defineCatalogHandler(catalogHandler);
builder.defineMetaHandler(metaHandler);
builder.defineStreamHandler(streamHandler);

(async () => {

    console.log("Loading playlists...");

    await loadChannels();

    console.log("Loading EPG...");

    const programmes = await loadEpg();

    loadProgrammes(programmes);

    console.log("Starting addon...");

    serveHTTP(builder.getInterface(), {
        port: config.addon.port
    });

    console.log("==================================");
    console.log("vaniTV v1");
    console.log(
        `Addon : http://${config.addon.host}:${config.addon.port}/manifest.json`
    );
    console.log("==================================");

})();